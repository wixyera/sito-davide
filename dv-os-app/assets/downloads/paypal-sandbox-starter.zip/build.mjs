import {cp,mkdir} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
for(const f of ['index.html','paypal-sandbox.html','css','js'])await cp(f,'dist/'+f,{recursive:true});
